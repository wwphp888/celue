function getQuote() {
	console.log('data'+data)
      return data;
    }